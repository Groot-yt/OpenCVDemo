package com.demo.opencvdemo3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfDouble;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        image = findViewById(R.id.image);
        TextView tv = findViewById(R.id.sample_text);
        tv.setText(stringFromJNI());
        findViewById(R.id.btn).setOnClickListener((view) -> {
            // processGray();
            // BinaryImage();
            // GaussianBluer();
            bilateralFilter();
        });

        if(OpenCVLoader.initDebug()){
            tv.append("\nload OpenCV Library successfully");
        }else {
            tv.append("\nload OpenCV Library Failed");
        }
    }

    private void processGray(){
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_win);
        Mat src = new Mat();
        Mat dst = new Mat();

        Utils.bitmapToMat(bitmap, src);
        Imgproc.cvtColor(src, dst, Imgproc.COLOR_BGRA2GRAY);
        Utils.matToBitmap(dst, bitmap);

        ImageView iv = findViewById(R.id.image);
        iv.setImageBitmap(bitmap);

        src.release();
        dst.release();
    }

    // 二值图 BW图
    private void BinaryImage(){
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_win);
        Mat src = new Mat();
        Mat gray = new Mat();

        Utils.bitmapToMat(bitmap, src);
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGRA2GRAY);
        src.release();

        // 计算均值与标准差
        MatOfDouble means = new MatOfDouble();
        MatOfDouble stddevs = new MatOfDouble();
        Core.meanStdDev(gray, means, stddevs);
        Log.d("yutao", "gray image means: " + means.toArray()[0]);
        Log.d("yutao", "gray image stddev: " + stddevs.toArray()[0]);

        // 读取像素数组
        int width = gray.cols();
        int height = gray.rows();
        byte[] data = new byte[width*height];
        gray.get(0, 0, data);
        int pv;

        // 根据均值进行二值分割
        int t = (int)means.toArray()[0];
        for (int i = 0; i < data.length; i++){
            pv = data[i]&0xff;
            if (pv > t){
                data[i] = (byte)255;
            }else {
                data[i] = (byte)0;
            }
        }
        gray.put(0, 0, data);

        Utils.matToBitmap(gray, bitmap);
        image.setImageBitmap(bitmap);

        gray.release();
    }

    // 高斯模糊
    private void GaussianBluer(){
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_win);
        Mat src = new Mat();
        Mat dst = new Mat();
        Utils.bitmapToMat(bitmap, src);

        Imgproc.GaussianBlur(src, dst, new Size(0, 0), 10);

        Utils.matToBitmap(dst, bitmap);
        ImageView iv = findViewById(R.id.image);
        iv.setImageBitmap(bitmap);

        src.release();
        dst.release();
    }

    // 高斯双边滤波
    private void bilateralFilter(){
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_blur1);
        Mat src = new Mat();
        Mat dst = new Mat();
        Utils.bitmapToMat(bitmap, src);

        Mat src1 = new Mat();
        Imgproc.cvtColor(src, src1, Imgproc.COLOR_BGRA2BGR);
        Imgproc.bilateralFilter(src1, dst, 0, 20, 10, 4);

        Utils.matToBitmap(dst, bitmap);
        image.setImageBitmap(bitmap);

        src.release();
        dst.release();
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
